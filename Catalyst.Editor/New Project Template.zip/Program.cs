﻿using Catalyst.Engine;
using System;

namespace Catalyst
{
    /// <summary>
    ///     The main class.
    /// </summary>
    public static class Program
    {
        /// <summary>
        ///     The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            using (var game = new Catalyst.Engine.Engine(Graphics.Width, Graphics.Height, "Catalyst", false))
            {
                game.Run();
            }
        }

        [STAThread]
        public static void Main(Scene scene)
        {
            using (var game = new Catalyst.Engine.Engine(scene, Graphics.Width, Graphics.Height, "Catalyst", false))
            {
                game.Run();
            }
        }

    }
}